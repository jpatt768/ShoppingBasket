//
//  Favourites.swift
//  ShoppingBasket
//
//  Created by Jayden Patterson on 2022/01/13.
//

import Foundation

struct Favourites: Codable {
    var favItem: String
    var favNote: String
}
