//
//  shoppingBasket.swift
//  ShoppingBasket
//
//  Created by Jayden Patterson on 2022/01/05.
//

import Foundation

struct ShoppingList: Codable {
    var item: String
    var note: String
}
