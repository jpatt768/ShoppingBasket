//
//  toDo.swift
//  ShoppingBasket
//
//  Created by Jayden Patterson on 2022/01/11.
//

import Foundation

struct ToDoList: Codable {
    var item: String
}
